<?php

    require("db_config.php");
    try
    {
        $db = new PDO($dsn, $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
    }
    catch(Exception $e)
    {                
        die('Erreur : ' . $e->getMessage());
    }

    if($_GET['where'] == 'recettes'){
        $db->query( 'DELETE FROM '.$_GET['where'].' WHERE rid="'.$_GET['id'].'"' );
    }elseif($_GET['where'] == 'supplements'){
        $db->query( 'DELETE FROM '.$_GET['where'].' WHERE sid="'.$_GET['id'].'"' );
    }elseif($_GET['where'] == 'extras'){
        $db->query( 'DELETE FROM '.$_GET['where'].' WHERE sid="'.$_GET['sid'].'", cid="'.$_GET['cid'].'"' );
    }

?>
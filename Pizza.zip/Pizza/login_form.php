<?php
include("header.php");
require('base.php');

?>

   <body>
    <form class="sign" method = "post">         
            
        <header>
        <a href="#"> <img src="images/logo1.png" width="300" height="100"> </a>
        </header>

        <label for="login" class="sr-only">Login</label>
        <input type="text" id="login" name="login" class="form-control" placeholder="Login" required autofocus>

        <label for="pwd" class="sr-only">Password</label>
        <input type="password" id="pwd" name="password" class="form-control" placeholder="Password" required>

        <input type="submit" value="Connexion"> <br>
        <span class="pull-right"><a href="<?= $pathFor['adduser'] ?>">S'enregistrer</a></span>
        
        <?php
            echo "<p class=\"error\">".($error??"")."</p>";
        ?>

    </form>
  </body>
<?php

include("footer.php");


<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <title>Hot Pizza</title>
    </head>
    <body>
        
    <?php
    
        require("db_config.php");
        try
        {
            $db = new PDO($dsn, $username, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
        catch(Exception $e)
        {                
            die('Erreur : ' . $e->getMessage());
        }

        //GLOBAL VARIABLES
        $rec_p = $db->query('SELECT prix FROM recettes');
        $rec_n = $db->query('SELECT nom FROM recettes');
        $sup_p = $db->query('SELECT prix FROM supplements'); 
        $sup_n = $db->query('SELECT nom FROM supplements'); 
        //$extra = $db->query('SELECT nom FROM extras');

    
        //recettes name
        $rec_name = [];
        $rn = 0;
        while($rnm = $rec_n->fetch()){
            $rec_name[$rn] = $rnm['nom'];
            $rn++;
        }
        $r_name = json_encode($rec_name);  
    
        //recettes price
        $rec_price = [];
        $rp = 0;
        while($rpc = $rec_p->fetch()){
            $rec_price[$rp] = $rpc['prix'];
            $rp++;
        }
        $r_price = json_encode($rec_price);  
    
        //supplements name
        $sup_name = [];
        $sn = 0;
        while($rnm = $sup_n->fetch()){
            $sup_name[$sn] = $rnm['nom'];
            $sn++;
        }
        $s_name = json_encode($sup_name);
    
        //supplements price
        $sup_price = [];
        $sp = 0;
        while($spc = $sup_p->fetch()){
            $sup_price[$sp] = $spc['prix'];
            $sp++;
        }
        $s_price = json_encode($sup_price); 
    
        

    ?>
    
    <script>
        var status = '<br> 0 € ';
        
        var items = [];
        items['recettes'] = [];
        items['supplements'] = [];
        items['extras'] = [];

        var r_name = <?php echo $r_name; ?>;
        var s_name = <?php echo $s_name; ?>;
        var e_name = [];
        
        var r_price = <?php echo $r_price; ?>;
        var s_price = <?php echo $s_price; ?>;
        var e_price = [];

        var s = <?php echo $sn; ?>;
        var r = <?php echo $rn; ?>;
        var i;


        for(i = 0; i < r; i++){
            items['recettes'][i] = 0;
        }
        for(i = 0; i < s; i++){
            items['supplements'][i] = 0;
        }
        
    </script>


</body>
</html>
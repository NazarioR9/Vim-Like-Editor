<!DOCTYPE html>
<html>
    
    <?php
        require("auth/EtreAuthentifie.php");
        require('base.php');
    ?>
    
    <link href="user_pizza.css" rel="stylesheet">
    
    <header>
        <a href="user_pizza.php"> <img src="images/logo1.png" width="200" height="50"> </a>
        <user> <button> <a href="<?= $pathFor['logout'] ?>" title="Logout">Logout</a> </button> </user>
    </header>
    
    <body>
    
    <?php
        require("db_config.php");
        try
        {
            $db = new PDO($dsn, $username, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
        catch(Exception $e)
        {                
            die('Erreur : ' . $e->getMessage());
        }

        $request = $db->query('SELECT * FROM commandes WHERE uid="'.$idm->getUid().'"');
    ?>

        <holder id="holder">
        <div class="container mt-3">
        
            <div class="d-flex mb-3">
                <div class="p-2">
                    <p> <strong>Menu : </strong><br> </p>
                    <nav>
                        <a href="user_pizza.php">Pizza</a>
                    </nav>
                    Supplements <br>
                    <nav>
                        <a href="commandes_history.php">Purchase history</a>
                    </nav>
                    
                </div>

                <div class="p-2 flex-grow-1">                    
                    <table class="table table-hover">
                        <tbody>
                                <tr>
                                    <td> 
                                        <?php echo '<strong> Your pizza has been ordered........ </strong> <br>'; ?>
                                        <?php echo '<strong> Thanks for choosing us </strong>'; ?>
                                    </td>
                                </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
        </holder>
    </body>
        
    <footer>
            
</html>

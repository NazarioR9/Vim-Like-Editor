<!DOCTYPE html>
<html>
    
    <link href="user_pizza.css" rel="stylesheet">
    
    <header>
        <a href="user_pizza.php"> <img src="images/logo1.png" width="200" height="50"> </a>
        <user> <button> <a href="index.php" title="home">Home</a> </button> </user>
    </header>
    
    <body>
        
        <div class="container mt-3">

            <?php
                require("db_config.php");
                try
                {
                    $db = new PDO($dsn, $username, $password);
                    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
                }
                catch(Exception $e)
                {                
                    die('Erreur : ' . $e->getMessage());
                }
                $supplements = $db->query('SELECT * FROM supplements');
            ?>
        
            <div class="d-flex mb-3">

                <div class="p-2 flex-grow-1">
                    <table class="table table-hover">
                        <tbody>
                            <?php
                            while($supplement = $supplements->fetch()){
                            ?>
                                <tr>
                                    <td> <?php echo $supplement['sid']; ?> </td>

                                    <td> 
                                        <?php 
                                            if($supplement['sid'] == 1){
                                        ?> 
                                                <img src="images/fromage.jpeg" width="300" height="200">
                                        <?php
                                            }elseif($supplement['sid'] == 2){
                                        ?>
                                                <img src="images/anchois.jpeg" width="300" height="200">
                                        <?php
                                            }elseif($supplement['sid'] == 3){
                                        ?>
                                                <img src="images/jambon.jpeg" width="300" height="200">
                                        <?php
                                            }elseif($supplement['sid'] == 4){
                                        ?>
                                                <img src="images/boisson.jpeg" width="300" height="200">
                                        <?php
                                            }elseif($supplement['sid'] == 5){
                                        ?>
                                                <img src="images/frite.jpeg" width="300" height="200">
                                        <?php
                                            }else{
                                        ?>
                                                <img src="images/oups.png" width="300" height="200">
                                        <?php
                                            }
                                        ?>
                                        
                                        <br>
                                        <strong>Name :  <?php echo $supplement['nom']; ?></strong>
                                        <br>
                                        <strong>Price :  <?php echo $supplement['prix']; ?>€</strong>

                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </body>
        
    <footer>
        
    </footer>
    
</html>
<?php

    require("db_config.php");
    try
    {
        $db = new PDO($dsn, $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
    }
    catch(Exception $e)
    {                
        die('Erreur : ' . $e->getMessage());
    }

    if($_GET['where'] == 'extras'){
        
        $cids = $db->query('SELECT cid FROM commandes WHERE ref="'.$_GET['ref'].'"');
        $cid = $cids->fetch();
        $db->query( 'INSERT INTO extras (cid, sid) VALUES ('.$cid['cid'].','.$_GET['sid'].')' );
        
    }

?>

<script>
    alert('Been in extras'+ '<?php echo $cid['cid']; ?>');

</script>
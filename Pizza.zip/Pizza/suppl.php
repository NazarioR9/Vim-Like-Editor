<?php

echo '<div class="container mt-3">';

require("db_config.php");
require("functions.php");
try
{
$db = new PDO($dsn, $username, $password);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
}
catch(Exception $e)
{                
die('Erreur : ' . $e->getMessage());
}
$supplements = $db->query('SELECT * FROM supplements');

echo '<div class="d-flex mb-3">';
echo '<div class="p-2">';
echo '<p> <strong>Menu : </strong><br> </p>';
echo 'Pizza <br>';
echo '<strong>Supplements</strong>';
echo '</div>';

echo '<div class="p-2 flex-grow-1">';
echo '<table class="table table-hover">';
echo '<tbody>';
while($supplement = $supplements->fetch()){
    echo '<tr>';
    echo  '<td> '.$supplement['sid'].'</td>';
    echo '<td>';
    if($supplement['sid'] == 1){
        echo '<img src="images/fromage.jpeg" width="300" height="200">';
    }elseif($supplement['sid'] == 2){
        echo '<img src="images/anchois.jpeg" width="300" height="200">';
    }elseif($supplement['sid'] == 3){
        echo '<img src="images/jambon.jpeg" width="300" height="200">';
    }elseif($supplement['sid'] == 4){
        echo '<img src="images/boisson.jpeg" width="300" height="200">';
    }elseif($supplement['sid'] == 5){
        echo '<img src="images/frite.jpeg" width="300" height="200">';
    }else{
        echo '<img src="images/oups.png" width="300" height="200">';
    }
    echo '<br>';
    echo '<strong>Name :  '.$supplement['nom'].' </strong>';
    echo '<br>';
    echo '<strong>Price :  '.$supplement['prix'].'€</strong>';

    echo '<form>';
    echo '<td> ';
    echo '<input type="button" name="add" class="butt_add" onclick="addRemove(1,<?php echo ($supplement[\'sid\']); ?>,"supplements")"  value="+1"> <br>';
    echo '<input type="button" name="rm" class="butt_rm" onclick="addRemove(-1,<?php echo ($supplement[\'sid\']); ?>,"supplements")"  value="- 1">';
    echo ' </td>';
    echo '</form>';

    echo '</td>';
    echo '</tr>';
}
echo '</tbody>';
echo '</table>';
echo '</div>';

echo '<div class="p-2">';
echo '<p> <strong>Commande :</strong></p>';
echo '<form>';
echo '<price id="price"> <script> document.write(price()); </script> </price> <br>';
echo '<input type="button" value="validate">';
echo '</form>';
echo '</div>';
echo '</div>';

echo '</div>';
    
?>
<?php

    require("db_config.php");
    try
    {
        $db = new PDO($dsn, $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
    }
    catch(Exception $e)
    {                
        die('Erreur : ' . $e->getMessage());
    }

    if($_GET['where'] == 'commandes'){
        $db->query( 'INSERT INTO commandes (ref, uid, rid, date) VALUES ("'.$_GET['ref'].'",'.$_GET['uid'].','.$_GET['rid'].',"'.$_GET['date'].'")' );
    }

?>
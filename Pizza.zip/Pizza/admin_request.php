<?php
        require("db_config.php");
        try
        {
            $db = new PDO($dsn, $username, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
        }
        catch(Exception $e)
        {                
            die('Erreur : ' . $e->getMessage());
        }
    
        $action = $_GET['action'];
        $categ = $_GET['categ'];

        if(isset($_GET['sort'])){
            $requests = $db->query('SELECT * from '.$categ.' ORDER BY '.$_GET['sort'].'');
        }else{
            $requests = $db->query('SELECT * from '.$categ.'');
        }

        if($action == 'liste'){
            echo '<table>';
            if($categ == 'recettes'){
                echo '<tr>';
                echo '<th> UID  </th>';
                echo '<th> NOM </th>';
                echo '<th> PRIX </th>';
                echo '</tr>';
                while($request = $requests->fetch()){
                    echo '<tr>';
                    echo '<td>   '.$request['rid'].'   </td>';
                    echo '<td>   '.$request['nom'].'   </td>';
                    echo '<td>   '.$request['prix'].'   </td>';
                    echo '</tr>';
                }
            }elseif($categ == 'supplements'){
                echo '<tr>';
                echo '<th> SID  </th>';
                echo '<th> NOM </th>';
                echo '<th> PRIX </th>';
                echo '</tr>';
                while($request = $requests->fetch()){
                    echo '<tr>';
                    echo '<td>   '.$request['sid'].'   </td>';
                    echo '<td>   '.$request['nom'].'   </td>';
                    echo '<td>   '.$request['prix'].'   </td>';
                    echo '</tr>';
                }
            }elseif($categ == 'commandes'){
                echo '<tr>';
                echo '<th> CID  </th>';
                echo '<th> REF </th>';
                echo '<th> UID </th>';
                echo '<th> RID </th>';
                echo '<th> DATE </th>';
                echo '<th> STATUT </th>';
                echo '</tr>';
                while($request = $requests->fetch()){
                    echo '<tr>';
                    echo '<td>   '.$request['cid'].'   </td>';
                    echo '<td>   '.$request['ref'].'   </td>';
                    echo '<td>   '.$request['uid'].'   </td>';
                    echo '<td>   '.$request['rid'].'   </td>';
                    echo '<td>   '.$request['date'].'   </td>';
                    echo '<td>   '.$request['statut'].'   </td>';
                    echo '</tr>';
                }
            }
            echo '<table>';
        }
        elseif($action == 'enregistrement'){
            if($categ == 'recettes'){
                echo '<br>Enregistrements <br>';
                echo '<form action="" >';
                echo '<input type="text" id="sr_n" name ="name" placeholder="nom" required> <br>';
                echo '<input type="number" id="sr_p" name ="price" placeholder="price" required> <br>';
                echo '<input type="text" id="sr_w" name ="where" value="recettes" disabled> <br>';
                echo '<input type="button" value="Insert" onclick="save_r()">';
                echo '</form>';
            }elseif($categ == 'supplements'){
                echo '<br>Enregistrements <br>';
                echo '<form action="" >';
                echo '<input type="text" id="ss_n" name ="name" placeholder="nom" required> <br>';
                echo '<input type="number" id="ss_p" name ="price" placeholder="price" required> <br>';
                echo '<input type="text" id="ss_w" name ="where" value="supplements" disabled> <br>';
                echo '<input type="button" value="Insert" onclick="save_s()">';
                echo '</form>';
            }else{
                echo 'Not available for this combo.......';
            }
        }
        elseif($action == 'modification'){
            if($categ == 'recettes'){
                echo ' Just a reminder..... : <br> ==> <br>';
                echo '<table>';
                echo '<tr>';
                echo '<th> UID  </th>';
                echo '<th> NOM </th>';
                echo '<th> PRIX </th>';
                echo '</tr>';
                while($request = $requests->fetch()){
                    echo '<tr>';
                    echo '<td>   '.$request['rid'].'   </td>';
                    echo '<td>   '.$request['nom'].'   </td>';
                    echo '<td>   '.$request['prix'].'   </td>';
                    echo '</tr>';
                }
                echo '<table>';
                echo '<br> <br>Modifications <br>';
                echo '<form action="" >';
                echo '<input type="number" id="mr_i" name ="rid" placeholder="Ancient rid" required> <br>';
                echo '<input type="text" id="mr_n" name ="name" placeholder="Nouvaeu nom" required> <br>';
                echo '<input type="text" id="mr_p" name ="price" placeholder="Nouveau prix" required> <br>';
                echo '<input type="text" id="mr_w" name ="where" value="recettes" disabled> <br>';
                echo '<input type="button" value="Modify" onclick="modify_r()">';
                echo '</form>';
            }elseif($categ == 'supplements'){
                echo ' Just a reminder..... : <br> ==> <br>';
                echo '<table>';
                echo '<tr>';
                echo '<th> SID  </th>';
                echo '<th> NOM </th>';
                echo '<th> PRIX </th>';
                echo '</tr>';
                while($request = $requests->fetch()){
                    echo '<tr>';
                    echo '<td>   '.$request['sid'].'   </td>';
                    echo '<td>   '.$request['nom'].'   </td>';
                    echo '<td>   '.$request['prix'].'   </td>';
                    echo '</tr>';
                }
                echo '<table>';
                echo '<br> <br>Modifications <br>';
                echo '<form action="" >';
                echo '<input type="number" id="ms_i" name ="sid" placeholder="Ancient sid" required> <br>';
                echo '<input type="text" id="ms_n" name ="name" placeholder="Nouvaeu nom" required> <br>';
                echo '<input type="text" id="ms_p" name ="price" placeholder="Nouveau prix" required> <br>';
                echo '<input type="text" id="ms_w" name ="where" value="supplements" disabled> <br>';
                echo '<input type="button" value="Modify" onclick="modify_s()">';
                echo '</form>';
            }else{
                echo 'Not available for this combo.......';
            }
        }
        elseif($action == 'suppression'){
            if($categ == 'recettes'){
                echo '<br> <br>Suppression <br>';
                echo '<form action="" >';
                echo '<input type="number" id="d_r" placeholder="rid" required> <br>';
                echo '<input type="text" id ="where" value="recettes" disabled> <br>';
                echo '<input type="button" value="Delete" onclick="delete_r()">';
                echo '</form>';
            }elseif($categ == 'supplements'){
                echo '<br> <br>Suppression <br>';
                echo '<form action="" >';
                echo '<input type="number" id="d_s" placeholder="sid" required> <br>';
                echo '<input type="text" id ="where" value="supplements" disabled> <br>';
                echo '<input type="button" value="Delete" onclick="delete_s()">';
                echo '</form>';
            }elseif($categ == 'extras'){
                echo '<br> <br>Suppression <br>';
                echo '<form action="">';
                echo '<input type="number" id="de_s" placeholder="sid" required> <br>';
                echo '<input type="number" id="de_c" placeholder="cid" required> <br>';
                echo '<input type="text" id ="where" value="extras" disabled> <br>';
                echo '<input type="button" value="Delete" onclick="delete_e()">';
                echo '</form>';
            }else{
                echo 'Not available for this combo.......';
            }
        }
?>

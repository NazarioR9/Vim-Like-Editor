<?php
$title="Ajout de l'utilisateur";
include("header.php");
include('base.php');
?>
<p class="error"><?= $error??""?></p>

    <body>
                
        <form class="sign" method = "post">         
            <!--legend>Inscription</legend-->
            
            <header>
                <a href="#"> <img src="images/logo1.png" width="200" height="50"> </a>
            </header>
            
            <label for="name" class="sr-only">Name</label>
            <input type="text" id="name" name="nom" class="form-control" placeholder="Name" required autofocus>

            <label for="lastName" class="sr-only">Last Name</label>
            <input type="text" id="lastName" name="prenom" class="form-control" placeholder="Last Name" required autofocus>

            <label for="login" class="sr-only">Login</label>
            <input type="text" id="login" name="login" class="form-control" placeholder="Login" required autofocus>

            <label for="pwd" class="sr-only">Password</label>
            <input type="password" id="pwd" name="mdp" class="form-control" placeholder="Password" required>
            
            <label for="pwd" class="sr-only">Password again</label>
            <input type="password" name="mdp2" class="form-control" id="pwd" placeholder="Repeat the password" required>

            <input type="submit" class="btn btn-primary" value="Register">
            
        </form>
    </body>


<?php

include("footer.php");

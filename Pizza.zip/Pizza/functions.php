
<?php
    require('base.php');    
?>


<script>
    
    var dict = ["A","B","C","D","E","F","G","H","I","J","K","L","M","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9"];
    
    function price(){
        var price = 0;
        status = " <br> ";
        
        for(i = 0; i < r; i++){
            if(items['recettes'][i] > 0){
                price += items['recettes'][i] * r_price[i] //********
                status += r_name[i] + " x" + items['recettes'][i] + '<br> '//********
            }
        }
        for(i = 0; i < s; i++){
            if(items['supplements'][i] > 0){
                price += items['supplements'][i] * s_price[i] //********
                status += s_name[i] + " x" + items['supplements'][i] + '<br> '//********
            }
        }
        status += price + " €";
        
        return status;
    }
    
    function addRemove(add, id, where){
        items[where][id] += add;
        if(items[where][id] < 0){
            items[where][id] = 0;
        }
        document.getElementById('price').innerHTML = price();
    }
    
    function validate(rid, uid){
        var ref = "";
        for(i = 0; i < 6; i++){
            var rand = Math.floor(Math.random()*100) % 37;
            ref += dict[rand];
        }

        var today = new Date();
        var d = String(today.getDate()).padStart(2, '0');
        var m = String(today.getMonth() + 1).padStart(2, '0'); //January is 0
        var y = today.getFullYear();
        var hour = String(today.getHours()).padStart(2, '0') + ":" + String(today.getMinutes()).padStart(2, '0') + ":" + String(today.getSeconds()).padStart(2, '0');
        var date = y+"-"+m+"-"+d+" "+hour;
        
        var xhttp;
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(data) {
            if (this.readyState == 4 && this.status == 200) {
                console.log(data);
            }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
            }
        };
        
        xhttp.open("GET", "commandes.php?ref="+ref+"&uid="+uid+"&rid="+ rid+"&date="+date+"&statut=preparation&where=commandes", true);
        xhttp.send();
        
        var delay = 0;
        while(delay < 50){
            delay++;
        }
        
        for(i = 0; i < s; i++){
            if(items['supplements'][i] > 0){
                var j;                
                for(j = 0; j < items['supplements'][i]; j++){
                    xhttp.open("GET", "extras.php?sid="+(i+1)+"&ref="+ref+"&where=extras", true);
                    xhttp.send();

                }
                
            }
        }
    }
    
</script>

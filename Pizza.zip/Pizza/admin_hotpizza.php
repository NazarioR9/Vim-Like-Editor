<!DOCTYPE html>
<html>
    
    <?php
        require('base.php');
    ?>
    
    <link href="user_pizza.css" rel="stylesheet">
    
    <header>
        <a href="admin_hotpizza.php"> <img src="images/logo1.png" width="200" height="50"> </a>
        <user> <button> <a href="<?= $pathFor['logout'] ?>" title="Logout">Logout</a> </button> </user>
    </header>
    
    <body>
        <holder id="holder">
        <div class="container mt-3">
        
                <div class="d-flex mb-3">
                    <h2> Admin page </h2>                    
                </div>

                <div class="p-2 flex-grow-1">                    
                    <table class="table table-hover">
                        <tbody>
                                <tr>
                                    <td> 
                                        <form action=""> 
                                          <select name="category" id="cat" onchange="changePlaceHolder(this.value)" required>
                                            <option value="">Choose a category:</option>
                                            <option value="recettes">Recettes</option>
                                            <option value="supplements">Supplements</option>
                                            <option value="extras">Extras</option>
                                            <option value="commandes">Commandes</option>
                                          </select>
                                          <place id="placeholder"></place>
                                          <br>
                                          <select name="action" id="act" required>
                                            <option value="">Choose an action:</option>
                                            <option value="liste">Liste</option>
                                            <option value="enregistrement">Enregistrement</option>
                                            <option value="modification">Modification</option>
                                            <option value="suppression">Suppression</option>
                                          </select>
                                          <br>
                                          <input type="button" value="Go !!" onclick="executeCommand()">
                                        </form>
                                    </td>
                                </tr>
                            
                                <tr>
				   <td>
                                    <div id="here">You request will be shown here...</div>
				   </td>
                                </tr>
                        </tbody>
                    </table>
                </div>
            
            </div>
        </holder>
    </body>

    <script>            
            function executeCommand() {
                var action = document.getElementById('act').value;
                var categ = document.getElementById('cat').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("here").innerHTML = this.responseText;
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                if(document.getElementById('sort') != null && categ == 'commandes'){
                    var holder = document.getElementById('sort').value;
                    xhttp.open("GET", "admin_request.php?action="+action+"&categ="+categ+"&sort="+holder, true);
                }else{
                    xhttp.open("GET", "admin_request.php?action="+action+"&categ="+categ, true);
                }
                xhttp.send();
            }
            
            function changePlaceHolder(str) {
                if(str != 'commandes'){
                    document.getElementById("placeholder").innerHTML = '';
                    return;
                }else{
                    document.getElementById("placeholder").innerHTML = '<select name="sortby" id="sort" > <option value="cid">Sort by :</option> <option value="cid">Nom</option> <option value="date">Date</option> <option value="statut">Type</option> </select>';
                }
            }
            
            function save_r(){
                var name = document.getElementById('sr_n').value;
                var price = document.getElementById('sr_p').value;
                var where = document.getElementById('sr_w').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function(data) {
                    if (this.readyState == 4 && this.status == 200) {
                        console.log(data);
                        alert('Saved with Success');
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                xhttp.open("GET", "save.php?name="+name+"&price="+price+"&where="+where, true);
                xhttp.send();
            }

            function save_s(){
                var name = document.getElementById('ss_n').value;
                var price = document.getElementById('ss_p').value;
                var where = document.getElementById('ss_w').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function(data) {
                    if (this.readyState == 4 && this.status == 200) {
                        console.log(data);
                        alert('Saved with Success');
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                xhttp.open("GET", "save.php?name="+name+"&price="+price+"&where="+where, true);
                xhttp.send();
            }

            function delete_r(){
                var id = document.getElementById('d_r').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        alert('Deleted with Success');
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                xhttp.open("GET", "delete.php?id="+id+"&where=recettes", true);
                xhttp.send();
            }

            function delete_s(){
                var id = document.getElementById('d_s').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        alert('Deleted with Success');
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                xhttp.open("GET", "delete.php?id="+id+"&where=supplements", true);
                xhttp.send();
            }
            
            function delete_e(){
                var sid = document.getElementById('de_s').value;
                var cid = document.getElementById('de_c').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        alert('Deleted with Success');
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                xhttp.open("GET", "delete.php?cid="+cid+"&sid="+sid+"&where=extras", true);
                xhttp.send();
            }
            
            function modify_r(){
                var id = document.getElementById('mr_i').value;
                var name = document.getElementById('mr_n').value;
                var price = document.getElementById('mr_p').value;
                var where = document.getElementById('mr_w').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function(data) {
                    if (this.readyState == 4 && this.status == 200) {
                        console.log(data);
                        alert('Saved with Success');
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                xhttp.open("GET", "modify.php?name="+name+"&price="+price+"&where="+ where+"&id="+id, true);
                xhttp.send();
            }
            
            function modify_s(){
                var id = document.getElementById('ms_i').value;
                var name = document.getElementById('ms_n').value;
                var price = document.getElementById('ms_p').value;
                var where = document.getElementById('ms_w').value;
                var xhttp;
                xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function(data) {
                    if (this.readyState == 4 && this.status == 200) {
                        console.log(data);
                        alert('Saved with Success');
                    }else if (xhttp.readyState === XMLHttpRequest.DONE && xhttp.status != 200) { // En cas d'erreur !
                        alert('Une erreur est survenue !\n\nCode :' + xhttp.status + '\nTexte : ' + xhttp.statusText);
                    }
                };
                xhttp.open("GET", "modify.php?name="+name+"&price="+price+"&where="+ where+"&id="+id, true);
                xhttp.send();
            }    
        </script>    
            
</html>

<?php

    require("db_config.php");
    try
    {
        $db = new PDO($dsn, $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
    }
    catch(Exception $e)
    {                
        die('Erreur : ' . $e->getMessage());
    }

    if($_GET['where'] == 'recettes'){
        $db->query( 'UPDATE recettes SET nom="'.$_GET['name'].'" ,prix="'.$_GET['price'].'" WHERE rid='.$_GET['id'].'' );
    }elseif($_GET['where'] == 'supplements'){
        $db->query( 'UPDATE supplements SET nom="'.$_GET['name'].'" ,prix="'.$_GET['price'].'" WHERE sid='.$_GET['id'].'' );
    }

?>
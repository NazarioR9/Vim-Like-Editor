<!DOCTYPE html>
<html>
    <link href="user_pizza.css" rel="stylesheet">
    
    <header>
        <a href="user_pizza.php"> <img src="images/logo1.png" width="200" height="50"> </a>
        <user> <button> <a href="index.php" title="home">Home</a> </button> </user>
    </header>
    
    <body >
        <holder id="holder">
        <div class="container mt-3">

            <?php
                require("db_config.php");
                try
                {
                    $db = new PDO($dsn, $username, $password);
                    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
                }
                catch(Exception $e)
                {                
                    die('Erreur : ' . $e->getMessage());
                }
                $pizzas = $db->query('SELECT * FROM recettes');
            ?>
        
            <div class="d-flex mb-3">

                <div class="p-2 flex-grow-1">
                    <table class="table table-hover">
                        <tbody>
                            <?php
                            while($pizza = $pizzas->fetch()){
                            ?>
                                <tr>
                                    <td> <?php echo $pizza['rid']; ?> </td>

                                    <td> 
                                        <?php 
                                            if($pizza['rid'] == 1){
                                        ?> 
                                                <img src="images/1.jpeg" alt="Margherita" width="250" height="200">
                                        <?php
                                            }elseif($pizza['rid'] == 2){
                                        ?>
                                                <img src="images/2.jpeg" alt="Regina" width="250" height="200">
                                        <?php
                                            }elseif($pizza['rid'] == 3){
                                        ?>
                                                <img src="images/3.jpeg" alt="Napoletana" width="250" height="200">
                                        <?php
                                            }elseif($pizza['rid'] == 4){
                                        ?>
                                                <img src="images/4.jpeg" alt="4 stagioni" width="250" height="200">
                                        <?php
                                            }else{
                                        ?>
                                                <img src="images/oups.png" width="250" height="200">
                                        <?php
                                            }
                                        ?>
                                        
                                        <br>
                                        <strong>Name :  <?php echo $pizza['nom']; ?></strong>
                                        <br>
                                        <strong>Price :  <?php echo $pizza['prix']; ?>€</strong>

                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
            
        </div>
        </holder>
    </body>
        
    <footer>
        
    </footer>
    
</html>
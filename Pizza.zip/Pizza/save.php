<?php

    require("db_config.php");
    try
    {
        $db = new PDO($dsn, $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
    }
    catch(Exception $e)
    {                
        die('Erreur : ' . $e->getMessage());
    }

    $db->query( 'INSERT INTO '.$_GET['where'].' (nom, prix) VALUES ("'.$_GET['name'].'","'.$_GET['price'].'")' );

?>
<!DOCTYPE html>
<html>
	<?php
	    require("auth/EtreAuthentifie.php");

	    if( $idm->getRole() == "admin" ){            

		require('admin_hotpizza.php');
	    }else{
		require('user_pizza.php');
	    }
	 ?>
</html>

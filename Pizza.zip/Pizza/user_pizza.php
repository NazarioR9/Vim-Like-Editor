
    <?php
    #require("auth/EtreAuthentifie.php");
    require('functions.php');
    require('base.php');
      
    ?>

    <link href="user_pizza.css" rel="stylesheet">
    
    <header>
        <a href="user_pizza.php"> <img src="images/logo1.png" width="200" height="50"> </a>
        <user> <button> <a href="<?= $pathFor['logout'] ?>" title="Logout">Logout</a> </button> </user>
    </header>
    
    <body >
        <holder id="holder">
        <div class="container mt-3">

            <?php
                require("db_config.php");
                try
                {
                    $db = new PDO($dsn, $username, $password);
                    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
                }
                catch(Exception $e)
                {                
                    die('Erreur : ' . $e->getMessage());
                }
                $pizzas = $db->query('SELECT * FROM recettes');
            ?>
        
            <div class="d-flex mb-3">
                <div class="p-2">
                    <p> <strong>Menu : </strong><br> </p>
                    <strong>Pizza</strong>
                    <br> Supplements <br>
                    <nav>
                        <a href="commandes_history.php">Purchase history</a>
                    </nav>
                    
                </div>

                <div class="p-2 flex-grow-1">
                    <table class="table table-hover">
                        <tbody>
                            <?php
                            while($pizza = $pizzas->fetch()){
                            ?>
                                <tr>
                                    <td> <?php echo $pizza['rid']; ?> </td>

                                    <td> 
                                        <?php 
                                            if($pizza['rid'] == 1){
                                        ?> 
                                                <img src="images/1.jpeg" alt="Margherita" width="250" height="200">
                                        <?php
                                            }elseif($pizza['rid'] == 2){
                                        ?>
                                                <img src="images/2.jpeg" alt="Regina" width="250" height="200">
                                        <?php
                                            }elseif($pizza['rid'] == 3){
                                        ?>
                                                <img src="images/3.jpeg" alt="Napoletana" width="250" height="200">
                                        <?php
                                            }elseif($pizza['rid'] == 4){
                                        ?>
                                                <img src="images/4.jpeg" alt="4 stagioni" width="250" height="200">
                                        <?php
                                            }else{
                                        ?>
                                                <img src="images/oups.png" width="250" height="200">
                                        <?php
                                            }
                                        ?>
                                        
                                        <br>
                                        <strong>Name :  <?php echo $pizza['nom']; ?></strong>
                                        <br>
                                        <strong>Price :  <?php echo $pizza['prix']; ?>€</strong>

                                        <form action="user_suppl.php" method="get">
                                            <td> 
                                                <input type="hidden" name="rid" value="<?php echo $pizza['rid']; ?>">
                                                <input name="select" type="submit" value="Select">
                                            </td>
                                        </form>

                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="p-2">
                    <strong>Commande :</strong><br>
                    <form>
                        <a id="price"> <script> document.write(price()); </script> </a> <br>
                        <input type="button" value="validate" disabled>
                    </form>
                </div>
            </div>
            
        </div>
        </holder>
    </body>
        
    <footer>
        
    </footer>
    
</html>
